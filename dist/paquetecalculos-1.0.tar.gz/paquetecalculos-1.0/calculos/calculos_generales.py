def sumar(op1, op2):
	print("El resultado de  la suma es: ", op1+op2)

def resta(op1, op2):
	print("El resultado de la resta: ", op1-op2)

def multiplicacion(op1,op2):
	print("El resultado de la multiplicacion es: ", op1*op2)

def dividir(dividiendo,divisor):
	print("El resultado de la division es: ", dividiendo*divisor)

def potencia(base, exponente):
	print("El resultado de la potencia es: ", base**exponente)

def redondear(numero):
	print("El resultado del redondeo es: ", round(numero))