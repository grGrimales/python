from setuptools import setup 

setup(

	name="paquetecalculos",
	version="1.0",
	description="Paquete de redondeo y potencia",
	author="Grediana",
	author_email="gredygrimales@gmail.com",
	packages=["calculos", "calculos.redondeo_potencia"]


	)